import ProgramEditor from './ProgramEditor';
export default function Page() { return <ProgramEditor />; }